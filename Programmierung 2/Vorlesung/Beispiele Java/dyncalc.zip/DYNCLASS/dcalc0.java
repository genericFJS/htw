class dcalc0 implements Calculate
{public double fVonX(double x){return Math.sqrt(x);}}
public interface Calculate
{
  public double fVonX(double x);
}
class dcalc2 implements Calculate
{public double fVonX(double x){return 2;}}
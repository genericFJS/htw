public class dcalc implements Calculate
{public double fVonX(double x){return Math.sin(x);}}
class dcalc3 implements Calculate
{public double fVonX(double x){return x*x+x;}}
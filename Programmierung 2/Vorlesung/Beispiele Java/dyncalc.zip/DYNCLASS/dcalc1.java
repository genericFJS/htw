class dcalc1 implements Calculate
{public double fVonX(double x){return ;}}